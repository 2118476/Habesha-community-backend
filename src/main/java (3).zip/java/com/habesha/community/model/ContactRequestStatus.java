package com.habesha.community.model;

public enum ContactRequestStatus { PENDING, APPROVED, REJECTED }
