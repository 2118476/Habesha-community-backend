package com.habesha.community.model;

public enum ContactType { EMAIL, PHONE }
