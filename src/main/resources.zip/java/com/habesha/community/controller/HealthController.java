package com.habesha.community.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Simple health check endpoint.
 *
 * <p>This controller exposes a lightweight endpoint that can be
 * queried by uptime monitoring services or platform health checks.
 * It returns a plain text response of "OK" when the application is
 * running. By permitting this endpoint without authentication, the
 * application can be pinged periodically to keep free hosting
 * platforms from idling the service.</p>
 */
@RestController
public class HealthController {

    /**
     * Health probe endpoint used to verify that the service is online.
     *
     * @return a static "OK" string
     */
    @GetMapping("/health")
    public String health() {
        return "OK";
    }
}