// src/main/java/com/habesha/community/dto/CancelFriendRequest.java
package com.habesha.community.dto;

import lombok.Data;

@Data
public class CancelFriendRequest {
    private Long requestId;
}
