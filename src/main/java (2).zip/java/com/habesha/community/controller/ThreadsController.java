// package com.habesha.community.controller;

// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;

// import java.util.Map;

// @RestController
// @RequestMapping("/api/messages/threads")
// public class ThreadsController {

//     @PostMapping("/ensure")
//     public ResponseEntity<?> ensureThread(@RequestParam("targetUserId") Long targetUserId) {
//         // TODO: look up or create a 1:1 thread and return its id
//         return ResponseEntity.ok(Map.of("id", "demo-thread-" + targetUserId));
//     }
// }
