package com.habesha.community.repository;

import com.habesha.community.model.HomeSwap;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HomeSwapRepository extends JpaRepository<HomeSwap, Long> {}
